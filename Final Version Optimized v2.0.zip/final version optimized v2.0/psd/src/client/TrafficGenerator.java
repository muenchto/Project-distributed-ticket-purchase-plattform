package client;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.zookeeper.WatchedEvent;

import remote.WideBox;
import zookeeper.ZKLibrary;
import zookeeper.ZKWatcher;

public class TrafficGenerator {

	static TrafficGenerator trafGen;
	public static final int NrTh = 1500;
	public static final int SERVER_PORT = 4001;
	public int reserves = 0;
	public int accepts = 0;
	public int requests = 0;
	public int cancels = 0;
	public int fails = 0;
	public double latency = 0.0f;
	public int nRequests = 0;
	public int full = 0;
	private static ZKLibrary zkl;

	public TrafficGenerator() {

	}

	public static void main(String[] args) throws AccessException, RemoteException, NotBoundException, InterruptedException {

		trafGen = new TrafficGenerator();

		Scanner scan = new Scanner(System.in);
		int time, clientChoice, theatreChoice;
		int rate;
		int zookeep;
		ConcurrentLinkedDeque<Double> averageLatency=new ConcurrentLinkedDeque<Double>();
		//String serverHost = args[0];
		zkl = new ZKLibrary("zoo.cfg", new TGWatcher()); // mudar
																		// para
																		// o
																		// path
																		// certo,
																		// qnd
																		// testarmos
		List<String> appServers = zkl.getAllZNodes("/zookeeper/appServer");
		int appCount = appServers.size();

		// chooses a random appServer to connect
		Random rand = new Random();
		int randAPP = rand.nextInt(appCount);
		String path = "/zookeeper/appServer/" + appServers.get(randAPP);
		String[] servInfo = zkl.getServerInfo(path).split(":");
		Registry registries[] = new Registry[appCount];
		WideBox widebox[] = new WideBox[appCount];
		int pos = 0;
		for (String s : appServers) {
			servInfo = zkl.getServerInfo("/zookeeper/appServer/" + s).split(":");
			registries[pos] = LocateRegistry.getRegistry(servInfo[0], Integer.parseInt(servInfo[1]));
			widebox[pos] = (WideBox) registries[pos].lookup("WideBox");

			pos++;
		}
		System.out.println("Welcome to Traffic Generator");
		System.out.println("Zookeeper for APP Server Distribution? 1-yes 2-no");
		zookeep = scan.nextInt();
		System.out.println("1-Query Mode 2-Purchase/Accept Mode");
		int choice = scan.nextInt();
		System.out.println("Please indicate executing time: ");
		time = scan.nextInt();
		System.out.println("Please choose rate(requests/sec): ");
		rate = scan.nextInt();

		System.out.println("1-single clientId or 2-Random client Id");
		clientChoice = scan.nextInt();
		System.out.println("1-single theatre or 2-Random theatre");
		theatreChoice = scan.nextInt();
		int[] choices = new int[4];
		choices[0] = choice;
		choices[1] = clientChoice;
		choices[2] = theatreChoice;
		choices[3] = zookeep;

		System.out.print("How many threads would you like to use:");
		int nThreads = scan.nextInt();
		System.out.print("With what frequency do you want to be updated about status? (in seconds) :");
		int reportInterval = scan.nextInt();
		scan.close();
		ExecutorService executor = Executors.newFixedThreadPool(nThreads + 1);
		if (zookeep == 1)
			for (int i = 0; i < nThreads; i++) {
				TrafficThread t = new TrafficThread(widebox[Math.abs(rand.nextInt(widebox.length)-1)], time, rate / nThreads,
						choices,averageLatency);
				
				executor.execute(t);
			}
		if(zookeep==2)
			for (int i = 0; i < nThreads; i++) {
				TrafficThread t = new TrafficThread(widebox[0], time, rate / nThreads,
						choices,averageLatency);
				executor.execute(t);
			}
		long startTime=System.nanoTime();
		executor.shutdown();

		// Wait until all threads are finished
		while (!executor.isTerminated()){
			Thread.sleep(reportInterval*1000); // wait for 1 second before reporting anything
			if(!executor.isTerminated()){
			System.out.print("TOTAL REQUESTS: ");
			System.out.println(trafGen.nRequests);

			System.out.print("RESERVES: ");
			System.out.println(trafGen.reserves);

			System.out.print("CANCELS: ");
			System.out.println(trafGen.cancels);

			System.out.print("COMMITS: ");
			System.out.println(trafGen.accepts);

			System.out.print("FAILS: ");
			System.out.println(trafGen.fails);

			System.out.print("FULL: ");
			System.out.println(trafGen.full);

			System.out.println("AVERAGE LATENCY: ");
			double total = 0;
				for (double d : averageLatency)
					total += d;
				System.out.println((total / averageLatency.size()) + "ms");
			
			System.out.print("REQUESTS PER SECOND: ");
			System.out.println(trafGen.requests / ((System.nanoTime()-startTime)/1000000000));
			}
			System.out.println("-------------------------------------");
			
		}
			
		System.out.println("\nAll threads finished !\n");

		System.out.println("-------------------------------------");
		System.out.println("STATISTICS - Client " + (choices[1] == 1 ? "Single ; " : "Random ; ") + "Theater "
				+ (choices[2] == 1 ? "Single ; " : "Random ; ") + (choices[0] == 1 ? "Query Mode" : "Purchase Mode"));
		System.out.println("-------------------------------------");

		// System.out.print("TOTAL REQUESTS EXPECTED: ");
		// System.out.println(trafGen.options[0] == 1 ?
		// (long)((long)rate*(long)duration*2) :
		// (long)((long)rate*(long)duration*2*(long)nThreads));

		System.out.print("TOTAL REQUESTS: ");
		System.out.println(trafGen.nRequests);

		System.out.print("RESERVES: ");
		System.out.println(trafGen.reserves);

		System.out.print("CANCELS: ");
		System.out.println(trafGen.cancels);

		System.out.print("COMMITS: ");
		System.out.println(trafGen.accepts);

		System.out.print("FAILS: ");
		System.out.println(trafGen.fails);

		System.out.print("FULL: ");
		System.out.println(trafGen.full);

		System.out.print("REQUESTS PER SECOND: ");
		System.out.println(trafGen.requests / time);
		
		System.out.println("AVERAGE LATENCY: ");
		double total = 0;
			for (double d : averageLatency)
				total += d;
			System.out.println((total / averageLatency.size()) + "ms");
		

		System.out.println("-------------------------------------");

	}
	
	private static class TGWatcher extends ZKWatcher {

		@Override
		public void process(WatchedEvent event) {
			// TODO Este se calhar vai ter de ir para dentro da TrafficThread

			switch (event.getType()) {
			case NodeDeleted:
				break;
			case NodeChildrenChanged:
//				System.out.println("APP Server has crashed");
//				zkl.setWatch("/zookeeper/appServer");
//				List<String> newAppServers = zkl.getAllZNodes("/zookeeper/appServer");
//				int newAppCount = newAppServers.size();
				break;
			case NodeCreated:
				break;
			case NodeDataChanged:
				break;
			default:
				break;
			}
		}
	}

}
