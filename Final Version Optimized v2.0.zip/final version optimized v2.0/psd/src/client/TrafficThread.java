package client;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedDeque;

import remote.Code;
import remote.Message;
import remote.WideBox;

public class TrafficThread extends Thread {

	private TrafficGenerator gen = TrafficGenerator.trafGen;

	private int clientId;
	private int theaterId;
	private int time;
	private int rate;
	private int[] choices;
	private WideBox widebox;
	private ConcurrentLinkedDeque<Double> averageLatency;
	
	public TrafficThread(WideBox widebox, int time, int rate, int[] choices,  ConcurrentLinkedDeque<Double> averageLatency) {
		this.widebox=widebox;
		this.time = time;
		this.rate = rate;
		this.choices = choices;
		this.averageLatency=averageLatency;
	}

	@SuppressWarnings("static-access")
	public void run() {
		int j = 0;
		Random rand = new Random();
		long taskTime = 0;
		long latencyBeg, latencyEnd;
		
			clientId = rand.nextInt(999999) + 1;
		
			theaterId = rand.nextInt(gen.NrTh);
		
		long timeInit= System.nanoTime();
		while (getTimePassed(timeInit) < time) { // duration of the generation of traffic

			j = 1;

			taskTime = System.nanoTime(); // to count the time spent

			while (j < rate) { // rate at which traffic is generated in a
									// second
				latencyBeg = System.nanoTime();
				// operation starts
				gen.requests++;

				Message msg = null;
				String seat = null;
				try {
					msg = widebox.initialRequest("Theater n" + theaterId, String.valueOf(clientId));
					if(msg.getCode().equals(Code.RESERVE_OK)){
						//System.out.println("Suggestion for seat "+msg.getSuggestedName()+" Thread "+this.getId());
						gen.reserves++;
					}else if(msg.getCode().equals(Code.RESERVE_ERROR)){
						gen.fails++;
					}
					gen.nRequests++;
				} catch (Exception e) {
					gen.fails++;
					System.out.println("ERROR IN THEATER: "+ theaterId);
					e.printStackTrace();
				}
				if (!msg.getCode().equals(Code.FULL)) {
					seat = msg.getSuggestedName();
					// if busy case to implement 2n phase
					if (choices[0] == 1) { // only query mode
						
						try {
					//		System.out.println("Canceling seat "+seat+" Thread "+this.getId());
							msg = widebox.cancelReservation("Theater n" + theaterId, String.valueOf(clientId),
									getSeatRow(seat), getSeatColumn(seat)-1);
	
							gen.nRequests++;
						} catch (RemoteException e) {
							gen.fails++;
							e.printStackTrace();
						}
						if (msg.getCode().equals(Code.CANCEL_OK))
							gen.cancels++;
						else if (msg.getCode().equals(Code.CANCEL_ERROR)){
							//System.out.println("Regular Cancel");
							//System.out.println(seat);
							//System.out.println(getSeatRow(seat));
							//System.out.println(getSeatColumn(seat));
							System.out.println("Cancel Error");
							gen.fails++;
						}
					} else if (choices[0] == 2) { // query/accept mode
						try {
						//	System.out.println("Accepting seat "+seat+" Thread "+this.getId());
							msg = widebox.acceptSeat("Theater n" + theaterId, String.valueOf(clientId), getSeatRow(seat),
									getSeatColumn(seat)-1);
							gen.nRequests++;
						} catch (IOException e) {
							System.out.println("Remote Exception");
							gen.fails++;
							e.printStackTrace();
						}
						if (msg.getCode().equals(Code.ACCEPT_OK))
							gen.accepts++;
						else if (msg.getCode().equals(Code.ACCEPT_ERROR)){
							System.out.println("ACCEPT ERROR");
							gen.fails++;
						}
					}
					
				}
				else
					gen.full++;
				latencyEnd = System.nanoTime();
				// add latency to calculations
				//synchronized(averageLatency){
					averageLatency.add((latencyEnd - latencyBeg) / 1000000.0);
			//	}
				if (choices[1] == 2) // random client ID
					clientId = rand.nextInt(999999) + 1;
				if (choices[2] == 2) // random theater
					theaterId = rand.nextInt(gen.NrTh);

				 // the actual
																// time it took
																// to realize
																// the complete
																// request

				// If a second or more as passed since the beggining of the
				// request
				if (getTimePassed(taskTime)>= 1)
					break;
				j++;
			}

			// the difference of time between the beginning and the end of the
			// traffic generation
			// in case there is still time
			if (1 - getTimePassed(taskTime) > 0)
				try {
					Thread.sleep(1-(int)getTimePassed(taskTime)); // sleep the rest of the time
													// until one second has
													// passed
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}
		System.out.println("TrafficThread has terminated");

	}

	private static int getSeatRow(String name) {
		String[] seat = name.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
		char pos = seat[0].charAt(0);
		return (int) pos - 65;
	}

	private static int getSeatColumn(String name) {
		String[] seat = name.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
		return Integer.parseInt(seat[1]);
	}
	
	private double getTimePassed(long initNano){
		
		return ((System.nanoTime()-initNano)/1000000000);
	}

}
