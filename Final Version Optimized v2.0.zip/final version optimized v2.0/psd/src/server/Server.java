package server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;

import remote.DbAccess;
import remote.State;
import remote.WideBox;
import widebox.Theater;
import zookeeper.ZKLibrary;
import zookeeper.ZKWatcher;

public class Server implements WideBox {
	private LinkedHashMap<String, Theater> theaters; // TODO maybe change to
														// LinkedHashMap
	private static final int PORT = 4000;
	// private static final int DB_PORT=5000;
	private static final int NrTh = 1500;
	// private DbAccess db;
	private static int membersAtStartUp;
	private Registry[] registries;
	private DbAccess[] dbs;
	private static ZKLibrary zkl;
	private static boolean backedup;
	private boolean dead;
	private int[][] allIntervals;

	public Server() throws RemoteException, NotBoundException {

		// se for preciso, descomentar o watcher e passa-lo aqui ao construtor
		zkl = new ZKLibrary("zoo.cfg", new APPWatcher());
		try {
			zkl.createZNode("/zookeeper/appServer", "Node with the APP servers".getBytes(), CreateMode.PERSISTENT);

			membersAtStartUp = zkl.getAllZNodes("/zookeeper/appServer").size() + 1;
			zkl.createZNode("/zookeeper/appServer/serv",
					(InetAddress.getLocalHost().toString().split("/")[1] + ":" + (PORT + membersAtStartUp)).getBytes(),
					CreateMode.EPHEMERAL_SEQUENTIAL);
			zkl.setWatch("/zookeeper/dbServer");
			System.out.println("this server's port is: " + (PORT + membersAtStartUp));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		this.dead = false;
		List<String> dbServers = zkl.getAllZNodes("/zookeeper/dbServer");
		int dbCount = dbServers.size();
		//this.allIntervals = new int[dbCount][4];
		backedup = true;
		String[] servInfo;
		registries = new Registry[dbCount];
		dbs = new DbAccess[dbCount];
		int pos = 0;
		for (String s : dbServers) {
			servInfo = zkl.getServerInfo("/zookeeper/dbServer/" + s).split(":");
			registries[pos] = LocateRegistry.getRegistry(servInfo[0], Integer.parseInt(servInfo[1]));
			dbs[pos] = (DbAccess) registries[pos].lookup("Database");

			System.out.println("Server: " + zkl.getServerInfo("/zookeeper/dbServer/" + s));
			// System.out.println("Log Interval
			// "+zkl.getLogInterval("/zookeeper/dbServer/"+s));

			pos++;
		}
		calculateIntervals();
		// chooses a random db to connect
		// Random rand = new Random();
		// int randDB = rand.nextInt(dbServers.size());
		// String path = "/zookeeper/dbServer/" + dbServers.get(randDB);
		// System.out.println("A db que foi escolhida foi: " + path);
		//
		// String[] db = zkl.getServerInfo(path).split(":");
		// System.out.println("IP: " + db[0] + "; Port: " + db[1]);

		// Registry registry = LocateRegistry.getRegistry(db[0],
		// Integer.parseInt(db[1]));
		// this.db = (DbAccess) registry.lookup("Database");

		this.theaters = new LinkedHashMap<String, Theater>();
		for (int i = 0; i < NrTh; i++) {
			this.theaters.put("Theater n" + i, new Theater(i));// note that
																// names start
																// at 0
		}

	}

	// RMI Methods
	public void reBuildDbServers() {
		List<String> dbServers = zkl.getAllZNodes("/zookeeper/dbServer");
		int dbCount = dbServers.size();
		String[] servInfo;
		registries = new Registry[dbCount];
		dbs = new DbAccess[dbCount];
		int pos = 0;
		for (String s : dbServers) {
			servInfo = zkl.getServerInfo("/zookeeper/dbServer/" + s).split(":");
			try {
				registries[pos] = LocateRegistry.getRegistry(servInfo[0], Integer.parseInt(servInfo[1]));
				dbs[pos] = (DbAccess) registries[pos].lookup("Database");
			} catch (NumberFormatException | RemoteException | NotBoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			//System.out.println("Server: " + zkl.getServerInfo("/zookeeper/dbServer/" + s));
			// System.out.println("Log Interval
			// "+zkl.getLogInterval("/zookeeper/dbServer/"+s));

			pos++;
		}
		calculateIntervals();
		dead = true;

	}

	public DbAccess getRightDB(String name) {
		if(!backedup && !dead){
			reBuildDbServers();
		}
		
		int thNumber = Integer.parseInt(name.split("n")[1]);
		
		//if primary is active
			for (int i = 0; i < allIntervals.length; i++) {
				if (thNumber >= allIntervals[i][0] && thNumber <= allIntervals[i][1]){
					return dbs[i];
				}

			}
			//otherwise use secundary
			for (int i = 0; i < allIntervals.length; i++) {
				if (thNumber >= allIntervals[i][2] && thNumber <= allIntervals[i][3]){
					return dbs[i];
				}
			}
		
		System.out.println(name);
		return null;
		// int thNumber = Integer.parseInt(name.split("n")[1]);
		// DbAccess rightDB = null;
		// int[] intervals;
		// int i = 0;
		// if (!backedup && !dead) {
		// reBuildDbServers();
		// }
		//
		// List<String> dbServers = zkl.getAllZNodes("/zookeeper/dbServer");
		// for (String s : dbServers) {
		// intervals = zkl.getNewLogInterval("/zookeeper/dbServer/" + s);
		// if (thNumber >= intervals[0] && thNumber <= intervals[1]) {
		// System.out.println(
		// "Redirecting " + name + " to PRIMARY : " +
		// zkl.getServerInfo("/zookeeper/dbServer/" + s));
		// rightDB = dbs[i];
		// }
		// i++;
		// }
		// i = 0;
		// if (!backedup && rightDB == null) {
		// for (String s : dbServers) {
		// intervals = zkl.getNewLogInterval("/zookeeper/dbServer/" + s);
		// if (thNumber >= intervals[2] && thNumber <= intervals[3]) {
		// System.out.println(
		// "Redirecting " + name + " to SECONDARY : " +
		// zkl.getServerInfo("/zookeeper/dbServer/" + s));
		// rightDB = dbs[i];
		// }
		// i++;
		// }
		// }

		// if(dbs.length == 1){
		// rightDB = dbs[0];
		// }
		// else if(dbs.length == 2){
		// if(thNumber < 750)
		// rightDB = dbs[0];
		// else
		// rightDB = dbs[1];
		// }
		// else if(dbs.length == 3){
		// if(thNumber < 500)
		// rightDB = dbs[0];
		// else if(thNumber >= 750 && thNumber < 1250){
		// rightDB = dbs[1];
		// }
		// else if((thNumber >= 500 && thNumber < 750) || (thNumber >= 1250 &&
		// thNumber <= 1499))
		// rightDB = dbs[2];
		// }
	
	}

	public List<String> getNames() throws RemoteException {
		ArrayList<String> names = new ArrayList<String>();
		for (DbAccess db : dbs) {
			names.addAll(db.getNames());
		}
		return names;
	}

	// TODO Method to return list
	@Override
	public State getSeatState(String name, int i, int j) throws RemoteException {
		return getRightDB(name).getSeatState(name, i, j);
	}

	@Override
	public String getSeatUser(String name, int i, int j) throws RemoteException {
		return getRightDB(name).getSeatUser(name, i, j);
	}

	// TODO think about occupation and reservation
	public remote.Message acceptSeat(String name, String user, int i, int j) throws IOException {
		return getRightDB(name).acceptSeat(name, user, i, j);
	}

	public remote.Message cancelReservation(String name, String user, int i, int j) throws RemoteException {
		return getRightDB(name).cancelReservation(name, user, i, j);
	}

	public remote.Message initialRequest(String name, String user) throws RemoteException {
		return getRightDB(name).initialRequest(name, user);
	}

	// TODO maybe change to [][]
	public String[][] getSeats(String name) throws RemoteException {
		return getRightDB(name).getSeats(name);
	}

	public remote.Message reserveSeat(String name, String user, int i, int j) throws RemoteException {
		return getRightDB(name).reserveSeat(name, user, i, j);
	}

	public remote.Message theaterState(String name) throws RemoteException {
		return getRightDB(name).theaterState(name);
	}

	public remote.Message reservations(String name, String user) throws RemoteException {
		return getRightDB(name).reservations(name, user);
	}

	public void kill() {
		System.out.println("Order to die");
		System.exit(0);
	}

	public void calculateIntervals() {
		int[] intervals;
		List<String> dbServers = zkl.getAllZNodes("/zookeeper/dbServer");
		allIntervals=new int[dbServers.size()][4];
		int i = 0;
		for (String s : dbServers) {
			intervals = zkl.getNewLogInterval("/zookeeper/dbServer/" + s);
			allIntervals[i] = intervals;
			i++;
		}

	}

	public static void main(String[] args) throws Exception {
		// Implement structure
		try {
			Server serv = new Server();
			WideBox widebox = (WideBox) UnicastRemoteObject.exportObject(serv, 0);
			// String address = System.getProperty("java.rmi.server.hostname");
			// String myID = ("address" +":"+"WideBox");
			Registry registry = LocateRegistry.createRegistry(PORT + membersAtStartUp);
			registry.bind("WideBox", widebox);
			System.err.println("Server Ready");
		} catch (Exception e) {
			System.err.print("Server Exception: " + e.toString());
			e.printStackTrace();
		}
	}

	private class APPWatcher extends ZKWatcher {
		@Override
		public void process(WatchedEvent event) {
			switch (event.getType()) {
			case NodeDeleted:
				break;
			case NodeChildrenChanged:
				System.out.println("Teste no DB Server");
				// zkl.setWatch("/zookeeper/dbServer");
				backedup = false;
				break;
			case NodeCreated:
				break;
			case NodeDataChanged:
				break;
			default:
				break;
			}
		}
	}
}
