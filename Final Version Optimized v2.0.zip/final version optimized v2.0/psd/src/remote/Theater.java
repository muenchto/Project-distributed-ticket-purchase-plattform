package remote;

public interface Theater{

	public String getName();
	public Seat[][] getSeats();
	
}
