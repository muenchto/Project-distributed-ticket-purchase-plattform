package remote;

import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface DbAccess extends Remote {

	public List<String> getNames() throws RemoteException;

	public State getSeatState(String name, int i, int j) throws RemoteException;

	public String getSeatUser(String name, int i, int j) throws RemoteException;

	public String[][] getSeats(String name) throws RemoteException;

	public Message acceptSeat(String name, String user, int i, int j) throws RemoteException, IOException;

	public Message cancelReservation(String name, String user, int i, int j) throws RemoteException;

	public Message reserveSeat(String name, String user, int i, int j) throws RemoteException;

	public Message reservations(String name, String user) throws RemoteException;

	public Message initialRequest(String name, String user) throws RemoteException;

	public Message theaterState(String name) throws RemoteException;

	public void kill() throws RemoteException;
	
	//public File [] logRequest(int number) throws RemoteException, IOException;
	
	public void secondaryUpdate(String name, String user, int i, int j) throws RemoteException, IOException;
}
