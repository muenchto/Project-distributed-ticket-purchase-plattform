package remote;

public enum State {
	FREE,
	OCCUPIED,
	RESERVED,
}
