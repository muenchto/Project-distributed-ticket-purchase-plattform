package db;

import java.io.FileWriter;
import java.util.ArrayList;

public class Appender extends Thread {

	private FileWriter[] fw;
	private ArrayList<String> memlog;

	public Appender(FileWriter[] fw, ArrayList<String> memlog) {
		this.fw = fw;
		this.memlog = memlog;
	}

	@Override
	public void run() {
		String[] decomp;
		int pos;
		while (true) {
			try {
				Thread.sleep(9001);
				if (!memlog.isEmpty()) {
					synchronized(memlog){
						for (String s : memlog) {
							decomp = s.split("DIVISION");
							pos = Integer.parseInt(decomp[0]);

							fw[pos].write(decomp[1]);
							fw[pos].flush();
						}
						memlog.clear();
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
