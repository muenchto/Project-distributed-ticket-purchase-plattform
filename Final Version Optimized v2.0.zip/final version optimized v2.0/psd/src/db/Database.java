package db;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;

import remote.Code;
import remote.DbAccess;
import remote.State;
import widebox.Theater;
import zookeeper.ZKLibrary;
import zookeeper.ZKWatcher;

public class Database implements DbAccess {
	// TODO maybe preserve operations in memory and write to disk only after a
	// certain threshold
	private static int primaryLogHigher, primaryLogLower, secondaryLogHigher, secondaryLogLower;
	private File[] logs;
	private FileWriter[] writer;
	private static final int PORT = 5000;
	private static final int NrTh = 1500;
//	private int operationCounter; // TODO maybe use to count
//	private ArrayList<String> memlog;
	// private Appender append;
	private static ZKLibrary zkl;
	private static int membersAtStartup;
	private LinkedHashMap<String, Theater> theaters;
	//private LinkedHashMap<String, Theater> secTheaters;
	private static int nservs;
	private static boolean dbsReady;
	private static boolean backedup;
	private DbAccess secondary;

	//static Database db;
	@SuppressWarnings("static-access")
	public Database() throws NumberFormatException, NotBoundException, IOException, InterruptedException {
	//	String nodePath = null;
		zkl = new ZKLibrary("zoo.cfg", new DBWatcher());
		try {
			zkl.createZNode("/zookeeper/dbServer", "Node with the DB servers".getBytes(), CreateMode.PERSISTENT);
			membersAtStartup = zkl.getAllZNodes("/zookeeper/dbServer").size() + 1;
			zkl.createZNode("/zookeeper/dbServer/serv",
					(InetAddress.getLocalHost().toString().split("/")[1] + ":" + (PORT + membersAtStartup)).getBytes(),
					CreateMode.EPHEMERAL_SEQUENTIAL);
			zkl.setWatch("/zookeeper/dbServer");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		if (membersAtStartup == 0)
			membersAtStartup = zkl.getAllZNodes("/zookeeper/dbServer").size();

		Thread.sleep(10000); // TODO can be set, servers need to be booted at
								// this time
		nservs = zkl.getAllZNodes("/zookeeper/dbServer").size();
		backedup = true;
		dbsReady = true;
		int totalLogs = NrTh / nservs;
		this.primaryLogLower = (membersAtStartup - 1) * totalLogs;
		this.primaryLogHigher = ((membersAtStartup) * totalLogs) - 1;
		this.secondaryLogLower = (membersAtStartup % nservs) * totalLogs;
		this.secondaryLogHigher = (((membersAtStartup + 1) % nservs) * totalLogs) - 1;
		if (secondaryLogHigher <= 0 || secondaryLogHigher == NrTh)
			secondaryLogHigher = NrTh - 1;
		if (primaryLogHigher == NrTh || primaryLogHigher <= 0)
			primaryLogHigher = NrTh - 1;
		System.out.println("Primary Range: " + primaryLogLower + "-" + primaryLogHigher);
		System.out.println("secondary Range: " + secondaryLogLower + "-" + secondaryLogHigher);
		//this.memlog = new ArrayList<String>();
		File dir = new File("logs" + membersAtStartup);
		if (!dir.exists())
			dir.mkdirs();
		System.out.println("PORT IS: " + (PORT + membersAtStartup));
		// if (membersAtStartup == 1) { // only creates all logs if it is the
		// first
		// member

		this.theaters = new LinkedHashMap<String, Theater>();
	//	this.secTheaters = new LinkedHashMap<String, Theater>();
		for (int i = primaryLogLower; i <= primaryLogHigher; i++) {
			this.theaters.put("Theater n" + i, new Theater(i));
		}
		for (int i = secondaryLogLower; i <= secondaryLogHigher; i++) {
			this.theaters.put("Theater n" + i, new Theater(i));
		}

		this.logs = new File[NrTh];
		this.writer = new FileWriter[NrTh];
		for (int i = 0; i < logs.length; i++) {
			logs[i] = new File("logs" + membersAtStartup + "/" + i);
			if (!logs[i].exists()) {
				try {
					writer[i] = new FileWriter(logs[i]);
				} catch (IOException e) {

					e.printStackTrace();
				}
			} else
				writer[i] = new FileWriter(logs[i], true);
		}
		logRecovery();
		// primaryLogInterval.add("0-1499");
		List<String> nodes = zkl.getAllZNodes("/zookeeper/dbServer");
		for (String s : nodes) {
			String address = zkl.getServerInfo("/zookeeper/dbServer/" + s);
			if (Integer.parseInt(address.split(":")[1]) == (PORT + membersAtStartup)) {
				// String logint = primaryLogInterval.toString();
				zkl.updateZNode("/zookeeper/dbServer/" + s,
						(InetAddress.getLocalHost().toString().split("/")[1] + ":" + (PORT + membersAtStartup) + ":"
								+ " PRIMARY" + primaryLogLower + "-" + primaryLogHigher + "SECONDARY"
								+ secondaryLogLower + "-" + secondaryLogHigher).getBytes());
			}
		}

		// append = new Appender(writer, memlog);
		// ExecutorService executor = Executors.newSingleThreadExecutor();
		// executor.execute(append);
	}

	public static void main(String args[]) throws Exception {
		try {
	
			Database db = new Database();
			DbAccess dbserv = (DbAccess) UnicastRemoteObject.exportObject(db, 0);
			Registry registry = LocateRegistry.createRegistry(PORT + membersAtStartup);		
			registry.bind("Database", dbserv);
			db.linkToBackup();
			System.err.println("Database running");
		} catch (Exception e) {
			System.err.println("Server exception : " + e.toString());
			e.printStackTrace();

		}
	}

	
	@SuppressWarnings("static-access")
	public void linkToBackup() throws InterruptedException, AccessException, RemoteException, NotBoundException{
		Thread.sleep(10000);
		List<String> nodes = zkl.getAllZNodes("/zookeeper/dbServer");
		for (String s : nodes) {
			//String address = zkl.getServerInfo("/zookeeper/dbServer/" + s);
			int[] intervals = zkl.getNewLogInterval("/zookeeper/dbServer/" + s);
			String[] servInfo;
			if (intervals[2] == this.primaryLogLower && intervals[3] == this.primaryLogHigher) {
				servInfo = zkl.getServerInfo("/zookeeper/dbServer/" + s).split(":");
				Registry backup = LocateRegistry.getRegistry(servInfo[0], Integer.parseInt(servInfo[1]));
				this.secondary = (DbAccess) backup.lookup("Database");
				this.backedup=true;
			}
		}
	}
	
	public List<String> getNames() {
		List<String> keys = new ArrayList<String>();

		for (Map.Entry<String, Theater> t : theaters.entrySet()) {
			keys.add(t.getKey());
		}
		return keys;
	}

	
	public State getSeatState(String name, int i, int j) {
		Theater t = theaters.get(name);
		return t.getSeatState(i, j);
	}

	public String getSeatUser(String name, int i, int j) {
		Theater t = theaters.get(name);
		return t.getSeat(i, j).getUser();
	}

	public remote.Message acceptSeat(String name, String user, int i, int j) throws IOException {
		Theater t = theaters.get(name);
		if (t.getSeatState(i, j).equals(State.RESERVED) && t.getSeat(i, j).getUser().equals(user)) {
			synchronized (t) {
				t.setSeatState(State.OCCUPIED, user, i, j);
			}

			synchronized (writer) {
				writer[t.getId()].write(name + "-" + i + "-" + j + "-" + user + "\n");
				writer[t.getId()].flush();
			}
			if(backedup)
				secondary.secondaryUpdate(name,user,i,j);
			return new remote.Message(remote.Code.ACCEPT_OK, getSeats(name)); // TODO
																				// NOT
																				// SURE
		}
		return new remote.Message(remote.Code.ACCEPT_ERROR, getSeats(name));
	}

	public remote.Message cancelReservation(String name, String user, int i, int j) {
		Theater t = theaters.get(name);
		if (t.getSeatState(i, j).equals(State.RESERVED)) {
			t.setSeatState(State.FREE, user, i, j);
			return new remote.Message(remote.Code.CANCEL_OK, getSeats(name)); // TODO
																				// NOT
																				// SURE
		}
		return new remote.Message(remote.Code.CANCEL_ERROR, getSeats(name));
	}

	public remote.Message initialRequest(String name, String user) {
		Theater t = theaters.get(name);
		String suggestion = suggestionReserve(name);
		if (suggestion.equals("ERROR")) {
			return new remote.Message(Code.FULL);
		}
		String[] seat = suggestion.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
		char pos = seat[0].charAt(0);
		if (t.isFull())
			return theaterState(name);
		return reserveSeat(name, user, (int) (pos) - 65, Integer.valueOf(seat[1]) - 1);
	}

	public remote.Message theaterState(String name) {
		if (theaters.get(name).isFull())
			return new remote.Message(remote.Code.FULL);
		else
			return new remote.Message(remote.Code.AVAILABLE, getSeats(name));
	}

	private String suggestionReserve(String name) {
		Theater t = theaters.get(name);
		return t.getFirstFreeSeat();
	}

	public remote.Message reserveSeat(String name, String user, int i, int j) {
		Timer timer = new Timer();
		Timeout timeout = new Timeout(name, user, i, j, this);
		Theater t = theaters.get(name);

		if (t.getSeatState(i, j).equals(State.FREE)) {
				t.setSeatState(State.RESERVED, user, i, j);
			
			timer.schedule(timeout, 15000);
			return new remote.Message(remote.Code.RESERVE_OK, getSeats(name), t.getSeat(i, j).getName());
		}
		return new remote.Message(remote.Code.RESERVE_ERROR, getSeats(name), t.getSeat(i, j).getName());
	}

	public remote.Message reservations(String name, String user) {
		Theater t = theaters.get(name);
		String reservation = t.reservedSeat(user);
		return new remote.Message(Code.RESERVATION, reservation);
	}

	public String[][] getSeats(String name) {
		String[][] string = new String[26][40];
		Theater t = theaters.get(name);
		for (int i = 0; i < t.getSeats().length; i++)
			for (int j = 0; j < t.getSeats()[i].length; j++)
				string[i][j] = (t.getSeat(i, j).getName() + "-" + t.getSeatState(i, j));
		return string;
	}

	public void kill() {
		System.out.println("Order to die");
		System.exit(0);
	}

//	private int members() {
//		int members = zkl.getAllZNodes("/zookeeper/dbServer").size();
//		return members;
//	}

	// public File[] logRequest(int number) throws IOException {
	// File[] send = new File[number];
	// // int limiter =
	// System.out.println("upper bound " + getUpperBounds()[0]);
	// int startingPos = (getUpperBounds()[0] - number + 1);// <-problem
	// for (int i = 0; startingPos <= getUpperBounds()[0]; startingPos++) {
	// send[i] = logs[startingPos];
	// //writer[startingPos].close();
	// theaters.remove("Theater n" + startingPos);
	// i++;
	// }
	// startingPos = logs.length - number;
	// resizeLog(startingPos, number);
	// return send;
	// }
	public void secondaryUpdate(String name, String user, int i, int j) throws IOException {
			System.out.println("Updating secondary section");
			Theater t = theaters.get(name);
			synchronized (t) {
				t.setSeatState(State.OCCUPIED, user, i, j);
			}
			synchronized (writer) {
				writer[t.getId()].write(name + "-" + i + "-" + j + "-" + user + "\n");
				writer[t.getId()].flush();
			}
		

	}

	// private void resizeLog(int startingPos, int number) throws
	// UnknownHostException {
	// List<String> intervals = null;
	// List<String> newInterval = new ArrayList<String>();
	// List<String> nodes = zkl.getAllZNodes("/zookeeper/dbServer");
	// String mynode = null;
	// for (String node : nodes) {
	// String address = zkl.getServerInfo("/zookeeper/dbServer/" + node);
	// if (Integer.parseInt(address.split(":")[1]) == (PORT + membersAtStartup))
	// {
	// mynode = node;
	// intervals = zkl.getLogInterval("/zookeeper/dbServer/" + node);
	// }
	// }
	// for (String interval : intervals) {
	// String interv[] = interval.replaceAll("[\\[\\]]", "").split("-");
	//
	// String s = interv[0] + "-" + (Integer.parseInt(interv[1]) - number /
	// intervals.size());
	// newInterval.add(s);
	// }
	// System.out.println("New Interval: " + newInterval.toString());
	// zkl.updateZNode("/zookeeper/dbServer/" + mynode,
	// (InetAddress.getLocalHost().toString().split("/")[1] + ":"
	// + (PORT + membersAtStartup) + ":" + newInterval).getBytes());
	//
	// // int newlength = NrTh /
	// // zkl.getAllZNodes("/zookeeper/dbServer").size();
	// // System.out.println("VALUE FOR NEWLENGTH: " +newlength + " VALUE FOR
	// // OLD LENGTH: " + logs.length);
	// // File[] newLogs = new File[logs.length];
	// // FileWriter[] newWriter = new FileWriter[logs.length];
	// // for (int i = 0; i < newlength; i++) {
	// // newLogs[i] = logs[i];
	// // newWriter[i]=writer[i];
	// // }
	// // // logs = newLogs;
	// // //writer=newWriter;
	// // logInterval= new ArrayList<String>();
	// // System.out.println("startingpos: " +startingPos + " startingPos +
	// // newlength-1 "+ (startingPos + newlength-1));
	// //
	// logInterval.add(newLogs[startingPos-newlength].getName()+"-"+newLogs[startingPos-1].getName());
	// // List<String>nodes=zkl.getAllZNodes("/zookeeper/dbServer");
	// // for(String s: nodes){
	// // String address=zkl.getServerInfo("/zookeeper/dbServer/" + s);
	// // if(Integer.parseInt(address.split(":")[1]) == (PORT +
	// // membersAtStartup)){
	// // String logint=logInterval.toString();
	// // zkl.updateZNode("/zookeeper/dbServer/"+s,
	// // (InetAddress.getLocalHost().toString().split("/")[1] + ":" + (PORT +
	// // membersAtStartup)+":"+logint).getBytes());
	// // }
	// // }
	// }

	// public int[] getUpperBounds() {
	// List<String> nodes = zkl.getAllZNodes("/zookeeper/dbServer");
	// List<String> intervals = null;
	// for (String node : nodes) {
	// String address = zkl.getServerInfo("/zookeeper/dbServer/" + node);
	// if (Integer.parseInt(address.split(":")[1]) == (PORT + membersAtStartup))
	// {
	// intervals = zkl.getLogInterval("/zookeeper/dbServer/" + node);
	// }
	// }
	// int[] bounds = new int[intervals.size()];
	// int i = 0;
	// for (String interval : intervals) {
	// String interv[] = interval.replaceAll("[\\[\\]]", "").split("-");
	// int bound = Integer.parseInt(interv[1]);
	// bounds[i] = bound;
	// i++;
	// }
	// return bounds;
	// }

	// public int[] getLowerBounds() {
	// List<String> nodes = zkl.getAllZNodes("/zookeeper/dbServer");
	// List<String> intervals = null;
	// for (String node : nodes) {
	// String address = zkl.getServerInfo("/zookeeper/dbServer/" + node);
	// if (Integer.parseInt(address.split(":")[1]) == (PORT + membersAtStartup))
	// {
	// intervals = zkl.getLogInterval("/zookeeper/dbServer/" + node);
	// }
	// }
	// int[] bounds = new int[intervals.size()];
	// int i = 0;
	// for (String interval : intervals) {
	// String interv[] = interval.replaceAll("[\\[\\]]", "").split("-");
	// int bound = Integer.parseInt(interv[0]);
	// bounds[i] = bound;
	// i++;
	// }
	// return bounds;
	// }


	public void logRecovery() throws IOException {
		System.out.println("recovering from log ");
		for (File f : logs) {
			if (f.length() > 0 && f != null) {
				BufferedReader buf = new BufferedReader(new FileReader(f));
				String line;
				while ((line = buf.readLine()) != null) {
					String[] op = line.split("-");
					System.out.println(line);
					theaters.get(op[0]).setSeatState(State.OCCUPIED, op[3], Integer.parseInt(op[1]),
							Integer.parseInt(op[2]));
				}
				buf.close();
			}
		}
	}

	private static class DBWatcher extends ZKWatcher {

		@Override
		public void process(WatchedEvent event) {
			switch (event.getType()) {
			case NodeDeleted:
				break;
			case NodeChildrenChanged:
				System.out.println("Teste no DB Server");
				zkl.setWatch("/zookeeper/dbServer");
				if(dbsReady)
					backedup = false;
				break;
			case NodeCreated:
				break;
			case NodeDataChanged:
				break;
			default:
				break;
			}
		}
	}
}
