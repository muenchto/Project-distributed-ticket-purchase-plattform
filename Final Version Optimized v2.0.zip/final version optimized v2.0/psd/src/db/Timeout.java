package db;

import java.util.TimerTask;

public class Timeout extends TimerTask{
	private String name;
	private String user;
	private int i;
	private int j;
	private Database db;
	
	public Timeout(String name,String user, int i, int j , Database db){
		this.name=name;
		this.user=user;
		this.i=i;
		this.j=j;
		this.db=db;
	}
	@Override
	public void run() {
		db.cancelReservation(name, user, i, j);
		
	}

	
}
