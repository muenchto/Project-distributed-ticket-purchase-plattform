package faultgenerator;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

import remote.DbAccess;
import remote.WideBox;

public class FaultGen {

	private static Registry registry;

	public static void main(String[] args) throws RemoteException, NotBoundException {
		Scanner scan = new Scanner(System.in);
		String ip = "";
		while (!ip.equals("quit")) {
			System.out.println("Welcome to Fault Generator, let's cause some Mayhem ;)");
			System.out.println("IP of Server to shutdown: ");
			ip = scan.nextLine();
			System.out.println("Port of Server to shutdown: ");
			int port = Integer.parseInt(scan.nextLine());
			System.out.println("Type of server to shutdowm: ");
			System.out.println("1-APP Server 2-DB Server");
			int type = scan.nextInt();

			if (type == 1) {
				registry = LocateRegistry.getRegistry(ip, port);
				WideBox widebox = (WideBox) registry.lookup("WideBox");
				widebox.kill();
			}
			else if(type ==2){
				registry = LocateRegistry.getRegistry(ip, port);
				DbAccess database = (DbAccess) registry.lookup("Database");
				database.kill();
			}

		}
		scan.close();

	}

}
