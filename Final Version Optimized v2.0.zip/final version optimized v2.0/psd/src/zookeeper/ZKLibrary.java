package zookeeper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

public class ZKLibrary {

	private ZooKeeper zk;
	
	public ZKLibrary (String configFile, ZKWatcher watcher){
		String zkConfig = readZkConfig(configFile);
		try {
			zk = new ZooKeeper(zkConfig, 1000, watcher);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public ZooKeeper getZKObject(){
		return this.zk;
	}
	
	public void setWatch(String path){
		try {
			System.out.println("Dentro do setWatch");
			zk.getChildren(path, true);
		} catch (KeeperException | InterruptedException e) {
			System.out.println("Node doesn't exist!");
		}
	}
	
	/*
	 * Method to read the zookeeper configuration file and return a string
	 * with the pair <ip>:<port> (I'm assuming that there's only one of these
	 * in the file, preceded by "zk", and it is already in the right format,
	 * just to make things easier #ezgame #ezlife). 
	 */
	public String readZkConfig(String configFile){
		BufferedReader br;
		String line = null;
		String zkConfig = null;
		String[] zkInfo = new String[2];
		try {
			br = new BufferedReader(new FileReader(configFile));
			while((line = br.readLine()) != null){
				zkInfo = line.split(" ");
				if(zkInfo[0].equals("zk"))
					zkConfig = zkInfo[1];
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return zkConfig;
	}
	
	// Method to create znode in zookeeper ensemble
	public void createZNode(String path, byte[] data, CreateMode createMode){
		try {
			zk.create(path, data, ZooDefs.Ids.OPEN_ACL_UNSAFE, createMode);
		} catch (KeeperException | InterruptedException e) {
			System.out.println("Node " + path + " ja existe.");
		}
	}
	
	// Method to check existence of znode and its status, if znode is available.
	public Stat existsZNode(String path){
		Stat nodeStat = null;
		try {
			nodeStat = zk.exists(path, false);
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		return nodeStat;
	}
	
	//Method to retrieve all of a znode's children
	public List<String> getAllZNodes(String path){
		List<String> children = null;
		try {
			if(existsZNode(path) != null){
				children = zk.getChildren(path, false);
				java.util.Collections.sort(children);
				if(children.size() == 3)
					System.out.println(children.get(0)+";"+children.get(1)+";"+children.get(2)+";");
			}
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		return children;
	}
	
	//Method to get the pair <ip>:<port> of a given server stored in the znode
	public String getServerInfo(String path){
		String[] serverData = new String[3];
		String servConfig = null;
		Stat nodeStat = null;
		try {
			if((nodeStat = existsZNode(path)) != null){
				serverData = (new String(zk.getData(path, false, nodeStat))).split(":");
				servConfig = serverData[0] + ":" + serverData[1];
			}
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		return servConfig;
	}
	
	public int[] getNewLogInterval(String path){
		List<String> intervalList = new ArrayList<String>();		
		String[] intervals = null;
		String servConfig = null;
		Stat nodeStat = null;
		int[] allIntervals = new int[4];
		int x = 0;

		try {
			if((nodeStat = existsZNode(path)) != null){
				String s=new String(zk.getData(path, false, nodeStat));
				System.out.println("loginterval: "+s);
				
				servConfig = s.split("PRIMARY")[1];
				System.out.println(servConfig);
				intervals = servConfig.split("SECONDARY");
				for(int i = 0; i < intervals.length; i++)
					intervalList.add(intervals[i]);
				for(String ints:intervalList){
					System.out.println(ints);
					allIntervals[x] = Integer.parseInt(ints.split("-")[0]);
					allIntervals[x+1] = Integer.parseInt(ints.split("-")[1]);
					x+=2;
				}
			}
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		return allIntervals;
	}
	
	
	// Method to update the data in a znode.
	public void updateZNode(String path, byte[] data){
		try {
			zk.setData(path, data, zk.exists(path,false).getVersion());
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	// Method to delete znode.
	public void deleteZNode(String path){
		try {
			zk.delete(path, zk.exists(path,false).getVersion());
		} catch (InterruptedException | KeeperException e) {
			e.printStackTrace();
		}
	}
	
	// Method to disconnect from zookeeper server.
	public void close() throws InterruptedException {
		zk.close();
	}
	
}
