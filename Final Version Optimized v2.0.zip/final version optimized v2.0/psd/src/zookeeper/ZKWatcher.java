package zookeeper;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;

public class ZKWatcher implements Watcher {

	public void process(WatchedEvent event) {

	}
}
