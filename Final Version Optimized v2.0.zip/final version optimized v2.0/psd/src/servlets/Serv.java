package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import remote.Code;
import remote.Message;
import remote.State;
import remote.WideBox;
import zookeeper.ZKLibrary;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/Serv")
public class Serv extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public static final int SERVER_PORT = 4000;
	public static final String HTML_START="<html><body>";
	public static final String HTML_END="</body></html>";
	private Registry registry;

    /**
     * Default constructor. 
     * @throws RemoteException 
     * @throws NumberFormatException 
     * @throws NotBoundException 
     */
    public Serv() throws NumberFormatException, RemoteException, NotBoundException {
		ZKLibrary zkl = new ZKLibrary("C:/Users/asus/git/psd/zoo.cfg", null); //mudar para o path certo, qnd testarmos
    	List<String> appServers = zkl.getAllZNodes("/zookeeper/appServer");
		int appCount = appServers.size();
		
		//chooses a random appServer to connect
		Random rand = new Random();
		int randAPP = rand.nextInt(appCount);
		String path = "/zookeeper/appServer/" + appServers.get(randAPP);
		System.out.println("O app que foi escolhido foi: " + path);
		
		String[] servInfo = zkl.getServerInfo(path).split(":");
		registry = LocateRegistry.getRegistry(servInfo[0], Integer.parseInt(servInfo[1]));
		System.out.println("o porto �: " + Integer.parseInt(servInfo[1]));
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		
		out.println(HTML_START); //se calhar nao e preciso
		
		if(request.getParameter("getTheaters") != null){
			showTheaters(request, response);
		}
		else if(request.getParameter("getSeats") != null){
			showSeats(request, response);
		}
		else if(request.getParameter("acceptSeat") != null){
			acceptSeat(request, response);
		}
		else if(request.getParameter("reserveSeat") != null){
			reserveSeat(request, response);
		}
		else if(request.getParameter("cancelReservation") != null){
			cancelReservation(request, response);
		}
		
		out.println(HTML_END); //se calhar nao e preciso
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	//METODOS AUXILIARES-----------------------------------------------------------------------
	
	protected void showTheaters(HttpServletRequest request, HttpServletResponse response){
		
		WideBox test = null;
		PrintWriter out = null;
		ArrayList<String> theaters = null;
		try {
			//so it can read the information from the widebox server
			//Registry registry = LocateRegistry.getRegistry("127.0.0.1", SERVER_PORT);
			test = (WideBox) registry.lookup("WideBox");
			
			//to print the response to the browser
			response.getWriter().append("Served at: ").append(request.getContextPath());
			out = response.getWriter();
			
			//list with the theater names
			theaters = (ArrayList<String>) test.getNames();
			
			//prints all the theaters
			out.println("Theaters available:");
			for(String s:theaters){
				out.println("<h3>"+ s +"</h3>");
			}
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void showSeats(HttpServletRequest request, HttpServletResponse response){
		WideBox test = null;
		PrintWriter out = null;
		String[][] seats = new String[26][40];
		Message msg = null;
		String userId = null;
		String theaterName = null;
		boolean hasSeatReserved = false;
		int userXR = 0;
		int userYR = 0;
//		int userXO = 0;
//		int userYO = 0;
		ArrayList<String> occupiedSeats = new ArrayList<String>();
		try {
			//so it can read the information from the widebox server
			//Registry registry = LocateRegistry.getRegistry("127.0.0.1", SERVER_PORT);
			test = (WideBox) registry.lookup("WideBox");
			
			//strings with theater name and user id
			theaterName = request.getParameter("theaterName");
			userId = request.getParameter("userId");
			
			//to print the response to the browser
			out = response.getWriter();
			
			//array with all the seats
			seats = test.getSeats(request.getParameter("theaterName"));
			
			//checks if the user already has a reserved seat and saves it if so
			for (int i = 0; i < seats.length; i++){
				for (int j = 0; j < seats[i].length; j++){
					if(test.getSeatState(theaterName, i, j).equals(State.RESERVED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
						hasSeatReserved = true;
						userXR = i;
						userYR = j;
					}
					if(test.getSeatState(theaterName, i, j).equals(State.OCCUPIED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
//						userXO = i;
//						userYO = j;
						occupiedSeats.add(String.valueOf(i) + ":" + String.valueOf(j));
					}
					
				}
			}
			
			//reserves a seat as a suggestion if he didn't have one
			if(!hasSeatReserved){
				msg = test.initialRequest(theaterName, userId);
				userXR = getSeatRow(msg.getSuggestedName());
				userYR = getSeatColumn(msg.getSuggestedName());
			}
			
			//gets the updated list of seats
			seats = test.getSeats(request.getParameter("theaterName"));
			
			//checks if theater is full
			if(!hasSeatReserved && msg.getCode().equals(remote.Code.FULL)){
				out.println("Theater is full!");
			}
			
			//else prints all the seats
			else{
				//prints the all the seats (including the accepted one)
				out.println("Seats available:");
				int c = 0;
				for (int i = 0; i < seats.length; i++){
					out.println("<h3></h3>");
					for (int j = 0; j < seats[i].length; j++){
						if(seats[i][j].split("-")[1].equals("RESERVED")){
							if(i == userXR && j == userYR)
								out.println("<text style=\"color:#ff00ff;\">" + seats[i][j].split("-")[0] + "</text>");
							else
								out.println("<text style=\"color:yellow;\">" + seats[i][j].split("-")[0] + "</text>");
						}
						else if(seats[i][j].split("-")[1].equals("OCCUPIED")){
							if(occupiedSeats.size() > c && i == Integer.parseInt(occupiedSeats.get(c).split(":")[0]) && 
									j == Integer.parseInt(occupiedSeats.get(c).split(":")[1])){
								out.println("<text style=\"color:#0000FF;\">" + seats[i][j].split("-")[0] + "</text>");
								c++;
							}

							else
								out.println("<text style=\"color:red;\">" + seats[i][j].split("-")[0] + "</text>");
						}
						else
							out.println("<text style=\"color:green;\">" + seats[i][j].split("-")[0] + "</text>");
						
						
						
//						if(i == userXR && j == userYR && seats[i][j].split("-")[1].equals("RESERVED"))
//							out.println("<text style=\"color:#00FFFF;\">" + seats[i][j].split("-")[0] + "</text>");
//						else if(occupiedSeats.size() > c){ 
//							if(i == Integer.parseInt(occupiedSeats.get(c).split(":")[0]) && 
//								j == Integer.parseInt(occupiedSeats.get(c).split(":")[1]) && 
//								seats[i][j].split("-")[1].equals("OCCUPIED")){
//								out.println("<text style=\"color:#0000FF;\">" + seats[i][j].split("-")[0] + "</text>");
//								c++;
//							}
//						}
//						else{
//							if(seats[i][j].split("-")[1].equals("FREE"))
//								out.println("<text style=\"color:green;\">" + seats[i][j].split("-")[0] + "</text>");
//							else if(seats[i][j].split("-")[1].equals("RESERVED"))
//								out.println("<text style=\"color:yellow;\">" + seats[i][j].split("-")[0] + "</text>");
//							else
//								out.println("<text style=\"color:red;\">" + seats[i][j].split("-")[0] + "</text>");
//						}
					}
				}
			}
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void acceptSeat(HttpServletRequest request, HttpServletResponse response){
		WideBox test = null;
		PrintWriter out = null;
		String[][] seats = new String[26][40];
		Message msg = null;
		String theaterName = null;
		String userId = null;
		String seatName = null;
		boolean hasSeatReserved = false;
		int userXR = 0;
		int userYR = 0;
//		int userXO = 0;
//		int userYO = 0;
		ArrayList<String> occupiedSeats = new ArrayList<String>();
		try {
			//so it can read the information from the widebox server
			//Registry registry = LocateRegistry.getRegistry("127.0.0.1", SERVER_PORT);
			test = (WideBox) registry.lookup("WideBox");
			
			//to print the response to the browser
			out = response.getWriter();
			
			//grabs theater name and user id from the jsp
			theaterName = request.getParameter("theaterName");
			userId = request.getParameter("userId");
			
			//get the user's reserved seat
			msg = test.reservations(theaterName, userId);
			seatName = msg.getReservations();
			
			//accepts the seat
			test.acceptSeat(theaterName, userId, getSeatRow(seatName), getSeatColumn(seatName));
			seats = test.getSeats(theaterName);
			
			//checks if the user already has a reserved seat and saves it if so
			for (int i = 0; i < seats.length; i++){
				for (int j = 0; j < seats[i].length; j++){
					if(test.getSeatState(theaterName, i, j).equals(State.RESERVED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
						hasSeatReserved = true;
						userXR = i;
						userYR = j;
					}
					if(test.getSeatState(theaterName, i, j).equals(State.OCCUPIED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
//						userXO = i;
//						userYO = j;
						occupiedSeats.add(String.valueOf(i) + ":" + String.valueOf(j));
					}
					
				}
			}
			
			//prints the all the seats (including the accepted one)
			out.println("Seats available:");
			int c = 0;
			for (int i = 0; i < seats.length; i++){
				out.println("<h3></h3>");
				for (int j = 0; j < seats[i].length; j++){
					if(seats[i][j].split("-")[1].equals("RESERVED")){
						if(i == userXR && j == userYR)
							out.println("<text style=\"color:#ff00ff;\">" + seats[i][j].split("-")[0] + "</text>");
						else
							out.println("<text style=\"color:yellow;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else if(seats[i][j].split("-")[1].equals("OCCUPIED")){
						if(occupiedSeats.size() > c && i == Integer.parseInt(occupiedSeats.get(c).split(":")[0]) && 
								j == Integer.parseInt(occupiedSeats.get(c).split(":")[1])){
							out.println("<text style=\"color:#0000FF;\">" + seats[i][j].split("-")[0] + "</text>");
							c++;
						}

						else
							out.println("<text style=\"color:red;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else
						out.println("<text style=\"color:green;\">" + seats[i][j].split("-")[0] + "</text>");
				}
			}
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void reserveSeat(HttpServletRequest request, HttpServletResponse response){
		WideBox test = null;
		PrintWriter out = null;
		String[][] seats = new String[26][40];
		Message msg = null;
		String theaterName = null;
		String userId = null;
		String seatRow = null;
		String seatColumn = null;
		boolean hasSeatReserved = false;
		int userXR = 0;
		int userYR = 0;
//		int userXO = 0;
//		int userYO = 0;
		ArrayList<String> occupiedSeats = new ArrayList<String>();
		try {
			//so it can read the information from the widebox server
			//Registry registry = LocateRegistry.getRegistry("127.0.0.1", SERVER_PORT);
			test = (WideBox) registry.lookup("WideBox");
			
			//to print the response to the browser
			out = response.getWriter();
			
			//grabs theater name and user id from the jsp
			theaterName = request.getParameter("theaterName");
			userId = request.getParameter("userId");
			seatRow = request.getParameter("seatRow");
			seatColumn = request.getParameter("seatColumn");
			
			//checks if the user already has a seat reserved
			if(!(msg = test.reservations(theaterName, userId)).getReservations().equals("ERROR")){
				//cancels the reserved seat
				System.out.println("Dentro do if que ver se o user tem alguma reserva");
				test.cancelReservation(theaterName, userId, getSeatRow(msg.getReservations()), getSeatColumn(msg.getReservations()));
			}
			
			//reserves the new seat
			Message reserveMsg = test.reserveSeat(theaterName, userId, Integer.parseInt(seatRow), Integer.parseInt(seatColumn));
			seats = test.getSeats(theaterName);
			
			//checks if the user already has a reserved seat and saves it if so
			for (int i = 0; i < seats.length; i++){
				for (int j = 0; j < seats[i].length; j++){
					if(test.getSeatState(theaterName, i, j).equals(State.RESERVED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
						hasSeatReserved = true;
						userXR = i;
						userYR = j;
					}
					if(test.getSeatState(theaterName, i, j).equals(State.OCCUPIED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
//						userXO = i;
//						userYO = j;
						occupiedSeats.add(String.valueOf(i) + ":" + String.valueOf(j));
					}
					
				}
			}

			//prints the all the seats (including the accepted one)
			out.println("Seats available:");
			int c = 0;
			for (int i = 0; i < seats.length; i++){
				out.println("<h3></h3>");
				for (int j = 0; j < seats[i].length; j++){
					if(seats[i][j].split("-")[1].equals("RESERVED")){
						if(i == userXR && j == userYR)
							out.println("<text style=\"color:#ff00ff;\">" + seats[i][j].split("-")[0] + "</text>");
						else
							out.println("<text style=\"color:yellow;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else if(seats[i][j].split("-")[1].equals("OCCUPIED")){
						if(occupiedSeats.size() > c && i == Integer.parseInt(occupiedSeats.get(c).split(":")[0]) && 
								j == Integer.parseInt(occupiedSeats.get(c).split(":")[1])){
							out.println("<text style=\"color:#0000FF;\">" + seats[i][j].split("-")[0] + "</text>");
							c++;
						}

						else
							out.println("<text style=\"color:red;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else
						out.println("<text style=\"color:green;\">" + seats[i][j].split("-")[0] + "</text>");
				}
			}
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void cancelReservation(HttpServletRequest request, HttpServletResponse response){
		WideBox test = null;
		PrintWriter out = null;
		String[][] seats = new String[26][40];
		Message msg = null;
		String theaterName = null;
		String userId = null;
		boolean hasSeatReserved = false;
		int userXR = 0;
		int userYR = 0;
//		int userXO = 0;
//		int userYO = 0;
		ArrayList<String> occupiedSeats = new ArrayList<String>();
		try {
			//so it can read the information from the widebox server
			//Registry registry = LocateRegistry.getRegistry("127.0.0.1", SERVER_PORT);
			test = (WideBox) registry.lookup("WideBox");
			
			//to print the response to the browser
			out = response.getWriter();
			
			//grabs theater name and user id from the jsp
			theaterName = request.getParameter("theaterName");
			userId = request.getParameter("userId");
		//	seatRow = request.getParameter("seatRow");
		//	seatColumn = request.getParameter("seatColumn");
			
			//checks if the user already has a seat reserved
			if(!(msg = test.reservations(theaterName, userId)).getReservations().equals("ERROR")){
				//cancels the reserved seat
				System.out.println("Dentro do if que ver se o user tem alguma reserva");
				test.cancelReservation(theaterName, userId, getSeatRow(msg.getReservations()), getSeatColumn(msg.getReservations()));
			}

			//prints the all the seats
			seats = test.getSeats(theaterName);
			
			//checks if the user already has a reserved seat and saves it if so
			for (int i = 0; i < seats.length; i++){
				for (int j = 0; j < seats[i].length; j++){
					if(test.getSeatState(theaterName, i, j).equals(State.RESERVED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
						hasSeatReserved = true;
						userXR = i;
						userYR = j;
					}
					if(test.getSeatState(theaterName, i, j).equals(State.OCCUPIED) 
							&& test.getSeatUser(theaterName, i, j).equals(userId)){
//						userXO = i;
//						userYO = j;
						occupiedSeats.add(String.valueOf(i) + ":" + String.valueOf(j));
					}
					
				}
			}
			
			//prints the all the seats (including the accepted one)
			out.println("Seats available:");
			int c = 0;
			for (int i = 0; i < seats.length; i++){
				out.println("<h3></h3>");
				for (int j = 0; j < seats[i].length; j++){
					if(seats[i][j].split("-")[1].equals("RESERVED")){
						if(i == userXR && j == userYR)
							out.println("<text style=\"color:#ff00ff;\">" + seats[i][j].split("-")[0] + "</text>");
						else
							out.println("<text style=\"color:yellow;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else if(seats[i][j].split("-")[1].equals("OCCUPIED")){
						if(occupiedSeats.size() > c && i == Integer.parseInt(occupiedSeats.get(c).split(":")[0]) && 
								j == Integer.parseInt(occupiedSeats.get(c).split(":")[1])){
							out.println("<text style=\"color:#0000FF;\">" + seats[i][j].split("-")[0] + "</text>");
							c++;
						}

						else
							out.println("<text style=\"color:red;\">" + seats[i][j].split("-")[0] + "</text>");
					}
					else
						out.println("<text style=\"color:green;\">" + seats[i][j].split("-")[0] + "</text>");
				}
			}
		} catch (NotBoundException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static int getSeatRow(String name) {
		String[] seat = name.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
		char pos = seat[0].charAt(0);
		return (int) pos - 65;
	}

	private static int getSeatColumn(String name) {
		String[] seat = name.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
		return Integer.parseInt(seat[1]) - 1;
	}
}
